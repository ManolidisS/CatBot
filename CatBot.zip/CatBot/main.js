const Discord = require('discord.js');
const axios = require('axios');
const { token } = require('./config.json');
const client = new Discord.Client({ intents: [Discord.Intents.FLAGS.GUILDS, Discord.Intents.FLAGS.GUILD_MESSAGES, Discord.Intents.FLAGS.GUILD_MESSAGE_TYPING] });
const PREFIX = '>';

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on('messageCreate', async message => {
    if (message.content === `${PREFIX}meow`) {
        try {
          const response = await axios.get('https://api.thecatapi.com/v1/images/search');
          const imageUrl = response.data[0].url;
          message.channel.send(imageUrl);
        } catch (error) {
          console.error(error);
        }
      }
    console.log(message.author+" said "+message.content);
});

client.login(token);